import greenfoot.*;  


public class Inimigo1 extends Inimigo
{
    
    public  Inimigo1(){
        this.vida = 5;
    }
    
    public void act()
    {
        movimentar();
    }
    
    private void movimentar(){
        move(2);
        if(Greenfoot.getRandomNumber(100) < 10){
            int angulo = Greenfoot.getRandomNumber(90);
            turn(angulo-45);
            
        }
        if(isAtEdge()){
            turn(180);
        }
    }
}
