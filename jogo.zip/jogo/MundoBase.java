import greenfoot.*;

/**
 * A "Planta" de todas as fases.
 * Define o CONTRATO: "Toda fase DEVE ter o método inimigoFoiDerrotado()"
 */
public abstract class MundoBase extends World {
    
    public MundoBase(int largura, int altura, int tamCelula) {
        super(largura, altura, tamCelula);
    }
    
    /**
     * O CONTRATO.
     * Este método é abstrato, forçando Fase1, Fase2, etc.
     * a escreverem sua própria lógica para esta ação.
     */
   public abstract void inimigoFoiDerrotado(Inimigo inimigoMorto);
}