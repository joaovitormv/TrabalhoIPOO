import greenfoot.*;
import java.util.List;

/**
 * Um Bastão, que é um tipo de Item.
 */
public class Porrete extends Item {
    
    private int dano = 1;
    private int alcance = 100; 
    private int knockback = 15;

    @Override
    public void atacar(Player portador) {
        
        // Pega todos os inimigos perto do PORTADOR (Jogador)
        List<Inimigo> inimigosPerto = portador.getInimigosNoAlcance(alcance);

        // Loop para bater em todos os inimigos no alcance
        for (Inimigo inimigo : inimigosPerto) {
            inimigo.levarDano(dano);
            inimigo.sofrerKnockback(knockback, portador);
        }
        
        Greenfoot.playSound("swing.wav");
    }
}
