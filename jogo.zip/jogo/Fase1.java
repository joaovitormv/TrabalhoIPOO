import greenfoot.*;

public class Fase1 extends MundoBase {
    
    private int inimigosDerrotados1 = 0;
    private int metaParaInimigo2 = 2; // quando derrotar 2 inimigos do tipo1, aparece um inimigo do tipo 2

    public Fase1() {
        super(800, 600, 1); 
    }

   
    @Override
    public void inimigoFoiDerrotado(Inimigo inimigoMorto) {
        
        if (inimigoMorto instanceof Inimigo1) {
            inimigosDerrotados1++;
        }
        
        // na fase 1, terao apenas 2 inimigos. mas depois, podemos aumentar essa hierarquia
        
        if (inimigosDerrotados1 >= metaParaInimigo2) {
            inimigosDerrotados1 = 0; // Zera o contador
            
            addObject(new Inimigo1(), getWidth() / 2, 100);
        }
    }
}