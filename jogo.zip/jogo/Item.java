

/**
 * O "Contrato". Qualquer classe que herdar (extends) de Item
 * é OBRIGADA a implementar seu próprio método atacar().
 */
public abstract class Item {
    
    
    public abstract void atacar(Player portador);
}
