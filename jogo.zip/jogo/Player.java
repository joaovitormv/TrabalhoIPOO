import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class Player extends Actor
{
    private Item itemEquipado;
    private int velocidade = 2;
    private int vida;
    
    public void act()
    {
        mover();
    }
    
    public Player(){
        this.itemEquipado = new Porrete(); //Magia da classe abstract
        vida = 10;
    }
    
    
    private void mover(){
        //O personagem move mais rapido na diagonal. mt trampo pra arrumar
        if(Greenfoot.isKeyDown("w")){
            setLocation(getX(), getY() - velocidade);
        }
        if(Greenfoot.isKeyDown("s")){
            setLocation(getX(), getY() + velocidade);
        }
        if(Greenfoot.isKeyDown("a")){
            setLocation(getX() - velocidade, getY());
        }
        if(Greenfoot.isKeyDown("d")){
            setLocation(getX() + velocidade, getY());
        }
        
    }
    
    private void Ataque(){
        if(Greenfoot.isKeyDown("space")){
            if(itemEquipado != null){
                itemEquipado.atacar(this);
            }
        }
    }
    
    //O item, na hora de atacar, precisa calcular os inimigos por perto. porem 
    //esse método getObjectsInRange é proteted na classe Actor. Por isso fiz isso
    public List<Inimigo> getInimigosNoAlcance(int alcance) {
        // Esta chamada é VÁLIDA, pois estamos DENTRO
        // da classe Jogador, que é um Actor.
        return getObjectsInRange(alcance, Inimigo.class);
    }

}
