import greenfoot.*;

public abstract class Inimigo extends Actor {
    
    
    protected int vida = 30; // 'protected' deixa as classes filhas mudarem


    public abstract void act(); 

    // Todos os inimigos PODEM levar dano
    public void levarDano(int dano) {
        this.vida = this.vida - dano;
        if (this.vida <= 0) {
            morrer();
        }
    }

    // Todos os inimigos PODEM sofrer knockback
    public void sofrerKnockback(int distancia, Actor atacante) {
        turnTowards(atacante.getX(), atacante.getY());
        turn(180);
        move(distancia);
    }

    // Todos os inimigos PODEM morrer
    protected void morrer() {
        MundoBase mundo = (MundoBase) getWorld();
        mundo.inimigoFoiDerrotado(this); 
        getWorld().removeObject(this);
    }
    
    
}
